<?php
include('session.php');
      confirm_logged_in();
      require("con.php");
      $oid = $_GET['offerid'];
      $camp_sql = "SELECT * FROM camps WHERE offerid = '$oid'";
      $campres = mysqli_query($conn,$camp_sql);
      $camp = mysqli_fetch_assoc($campres);

$name = $camp['name'];
$shrtName = $camp['shrtName'];
$user = $camp['user'];
$refer = $camp['refer'];
$trackingUrl = $camp['tracking'];
$head = $camp['head'];
$step1 = $camp['step1'];
$step2 = $camp['step2'];
$cond = $camp['des'];

$al1num = mysqli_num_rows($campres);
if ($al1num == 0){
    echo 'Offerid Not Exists';
    return;
}
else {
?>
<script>if(performance.navigation.type == 2){
   location.reload(true);
}</script>
<!doctype html>
<html>
<head>
  <meta name="apple-mobile-web-app-status-bar-style" content="#FFB700">
  <meta name="description" content="Onx in an affiliate marketing portal. here you will get many offers with high payout 100% Indian 100% Trusted">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://unpkg.com/@themesberg/flowbite@1.3.0/dist/flowbite.min.css" />
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>Home</title>
   <script src="https://cdn.tailwindcss.com"></script>
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="./Admin/Assets/loader.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<script src="https://unpkg.com/flowbite@1.5.3/dist/datepicker.js"></script>
<script>
    if (localStorage.getItem('color-theme') === 'dark' || (!('color-theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark')
    }
</script>

</head>
<body class="dark:bg-gray-600" style="font-family: 'Poppins', sans-serif;">
        <div id="preloader"></div>
<nav class="bg-white shadow-md border-gray-200 px-2 sm:px-4 py-2.5 rounded dark:bg-gray-800">
  <div class="container flex flex-wrap justify-between items-center mx-auto">
    <a href="#" class="flex items-center">
        <img src="Https://OnxCamp.xyz/IPay/onx.png" class="mr-3 h-9 sm:h-9 rounded-full" alt="Onx" />
        <span class="self-center text-xl font-semibold whitespace-nowrap dark:text-white">Splash Media</span>
    </a>
    <div class="flex md:order-2">
    <button id="theme-toggle" type="button" class="text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 rounded-lg text-sm p-2.5">
    <svg id="theme-toggle-dark-icon" class="hidden w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z"></path></svg>
    <svg id="theme-toggle-light-icon" class="hidden w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" fill-rule="evenodd" clip-rule="evenodd"></path></svg>
</button>
    
    
    
    <button data-collapse-toggle="mobile-menu" type="button" class="inline-flex items-center p-2 ml-3 text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="mobile-menu" aria-expanded="false">
      <span class="sr-only">Open main menu</span>
      <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path></svg>
      <svg class="hidden w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
    </button>
    </div>
    <div class="hidden w-full md:block md:w-auto rounded" id="mobile-menu">
      <ul class="flex flex-col mt-4 md:flex-row md:space-x-8 md:mt-0 md:text-sm md:font-medium">
        <li>
          <a href="admin.php" class="block py-2 pr-4 pl-3 text-gray-700 border-b border-gray-100 hover:bg-gray-50 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700"><i class="fas fa-home"></i> DashBoard</a>
        </li>
        <li>
          <a href="live.php" class="block py-2 pr-4 pl-3 text-white bg-blue-700 rounded md:bg-transparent md:text-blue-700 md:p-0 dark:text-white"><i class="far fa-ballot-check"></i> Live Offers</a>
        </li>
        <li>
          <a href="coust.php" class="block py-2 pr-4 pl-3 text-gray-700 border-b border-gray-100 hover:bg-gray-50 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700"><i class="far fa-edit"></i> Coustmise</a>
        </li>
        <li>
          <a href="peoples.php" class="block py-2 pr-4 pl-3 text-gray-700 border-b border-gray-100 hover:bg-gray-50 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700"><i class="fas fa-user-friends"></i> Registered Refer</a>
        </li>
        <li>
          <a href="restore.php" class="block py-2 pr-4 pl-3 text-gray-700 border-b border-gray-100 hover:bg-gray-50 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700"><i class="fas fa-refresh"></i> Restore</a>
        </li>
        <li>
          <a href="logout.php" class="block py-2 pr-4 pl-3 text-gray-700 border-b border-gray-100 hover:bg-gray-50 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700"><i class="fas fa-sign-out"></i> Logout</a>
        </li>
        </ul>
    </div>
  </div>
</nav>
<div class="p-2">
<form method="POST">
    <div class="p-4">
  <div class="grid gap-4 mb-4 md:grid-cols-1">
        <div>
    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Campaign Name (Hame Page And Offer)</label>
    <input type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" name = "name" value="<?php echo $name;?>" requiredd>
</div>

  <div class="mb-3">
    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Short Name (For Url No Space)</label>
    <input type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" name = "shrtName" value="<?php echo $shrtName;?>" required>
  </div>

  <div class="mb-3">
    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Offer Id (For Refer Checker)</label>
    <input type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" name = "offerid" value="<?php echo $oid;?>" required>
  </div>

  <div class="mb-3">
    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">User Amount</label>
    <input type="number" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" name = "user" value="<?php echo $user;?>" required>
  </div>

  <div class="mb-3">
    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Refer Amount</label>
    <input type="number" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" name = "refer" value="<?php echo $refer;?>" required>
  </div>

  <div class="mb-3">
    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Tracking URL</label>
    <input type="url" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" name = "url" value="<?php echo $trackingUrl;?>" required>
  </div>

  <div class="mb-3">
    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Heading</label>
    <input type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" name = "head" value="<?php echo $head;?>" required>
  </div>

  <div class="mb-3">
    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Step1</label>
    <input type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" name = "step1" value="<?php echo $step1;?>" required>
  </div>

  <div class="mb-3">
    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Step2</label>
    <input type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" name = "step2" value="<?php echo $step2;?>">
  </div>

  <div class="mb-3">
    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Discription</label>
    <input type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" name = "des" value="<?php echo $cond;?>" required>
  </div>

  <button type="submit" name="update" class="text-white bg-gradient-to-br from-purple-600 to-blue-500 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Submit</button>
</form>
<?php
}
?>
</div>
	</section>
	<script src="https://unpkg.com/@themesberg/flowbite@1.3.0/dist/flowbite.bundle.js"></script>
<script src="./Assets/dark.js"></script>
<script src="./Assets/animate.js"></script>

</body>
</html>
<?php
if (isset($_POST['update'])) {
  include('con.php');
  
  $name1=$_POST['name'];
  $shrt=$_POST['shrtName'];
  $offerid1=$_POST['offerid'];
  $perrefer=$_POST['refer'];
  $peruser=$_POST['user'];
  $tracker=$_POST['url'];
  $title=$_POST['head'];
  $stepz1=$_POST['step1'];
  $stepz2=$_POST['step2'];
  $descrp=$_POST['des'];
  $sql="UPDATE camps SET name='$name' , shrtName='$shrt' , offerid='$offerid1' , user='$peruser' , refer='$perrefer' , tracking='$tracker' , head='$title' , step1='$stepz1' , step2='$stepz2' , des='$descrp' where offerid=$oid";
  			$resultset = mysqli_query($conn, $sql);
  			if($resultset){
  			      echo "<script>alert('Changes Successfully Updated !')</script>";
                  echo '<meta http-equiv="refresh" content="0; url=live.php">';
  			}else{
  			  echo "something went wrong";
  			}
}


?>