<?php
require("con.php");
$camp = $_GET['camp'];
$refid = $_GET['ref'];
$sqli = "SELECT * FROM refer where code= '$refid'";
$resultseti = mysqli_query($conn, $sqli);
$recordi = mysqli_fetch_assoc($resultseti);
$num = mysqli_num_rows($resultseti);
$sql = "SELECT * FROM camps WHERE shrtName = '$camp'";
$res = mysqli_query($conn,$sql);
$camp = mysqli_fetch_assoc($res);
$num = mysqli_num_rows($res);
?>
<script>
if(performance.navigation.type == 2){
   location.reload(true);
}
</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="theme-color" content="#000000">
<meta name="msapplication-navbutton-color" content="#000000">
<meta name="apple-mobile-web-app-status-bar-style" content="#000000">
  <meta name="description" content="Existing Campaign Offers Here ! - for Campaign Makers For Better Campaigns.">
  <meta property='og:url' content="https://Onxcamp.xyz/Pay"/>
  <meta property='og:type' content="website"/>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo $camp['name']?> - OnxCamps</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600;700;800&display=swap" rel="stylesheet">
  <script src="https://unpkg.com/flowbite@1.4.7/dist/flowbite.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma-rtl.min.css">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tw-elements/dist/css/index.min.css" />
<script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/flowbite@1.4.7/dist/flowbite.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.9.4/css/bulma-rtl.css" integrity="sha512-I6081wbkOhUzrW0pbGj2RxCnnCVqUDxQQE/PZq1WmvRSPlZ/2p6h1XbEnhFH4IqF759e10t+IuHjcs0ZYx9NWA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://unpkg.com/flowbite@1.4.7/dist/flowbite.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.9.4/css/bulma-rtl.min.css" integrity="sha512-zQwCzko7uofuMafJv7wahf3r1A8GC6lUaDlvoYXuoYggqD82RW2quUy7L97odQNcL8u/N8DJBOoIuiGAI2auBQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.9.4/css/bulma.css" integrity="sha512-SI0aF82pT58nyOjCNfyeE2Y5/KHId8cLIX/1VYzdjTRs0HPNswsJR+aLQYSWpb88GDJieAgR4g1XWZvUROQv1A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.9.4/css/bulma.min.css" integrity="sha512-HqxHUkJM0SYcbvxUw5P60SzdOTy/QVwA1JJrvaXJv4q7lmbDZCmZaqz01UPOaQveoxfYRv1tHozWGPMcuTBuvQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://unpkg.com/flowbite@1.4.7/dist/flowbite.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;900&family=Koulen&family=Square+Peg&family=Tapestry&family=Water+Brush&display=swap" rel="stylesheet">

</head>
<style>
	.jost{
		font-family:'Jost',sans-serif;
		}
		audio { display:none;}
	</style>
<body class="dark:bg-gray-600" style="font-family: 'Montserrat', sans-serif;">
<nav class="bg-white shadow-md border-gray-200 px-2 sm:px-4 py-2.5 rounded dark:bg-gray-800">
  <div class="container flex flex-wrap justify-between items-center mx-auto">
    <a href="#" class="flex items-center">
        <img src="Https://OnxCamp.xyz/IPay/onx.png" class="mr-3 h-9 sm:h-9 rounded-full" alt="Onx" />
        <span class="self-center text-xl font-semibold whitespace-nowrap dark:text-white">Splash Media Offers</span>
    </a>
  <div class="flex md:order-2">
        <span class="tag is-success">
    +₹ <?php echo $camp['user']; ?> </span>
  </div>
</nav>
<div class="p-2">
    <?php
            if ($num == 0){
                echo '<body>
                <center>
                <div class="p-4">
                <span class="login100-form-title p-b-20 my-4" style="color:red;font-size:20px !important;">Campaign Not Exists Over</span>
                </center>
                </div>
                </body>';
                echo "<meta http-equiv='refresh' content=0.1;url='https://telegram.dog/OnxCamps'>";
                return;
            }
            if ($camp['status'] !== "Active"){
                echo '<body>
                <center>
                <div class="p-4">
                <span class="login100-form-title p-b-20 my-4" style="color:red;font-size:20px !important;">Campaign Paused / Off</span>
                </center>
                </div>
                </body>';
                echo "<meta http-equiv='refresh' content=0.1;url='https://telegram.dog/OnxCamps'>";
                return;
            }
                if (isset($_POST['number'])){
                    $paytm = $_POST['number'];
                    $refer = $recordi['number'];
                    $trk1 = $camp['tracking'];
                    $track = $camp['panel'];
                    $track2 = $camp['panel1'];
                    $trk2 = "$trk1&$track=$paytm&$track2=$refer";
                    
                    echo '<body>
                    <center>
                    <div class="p-4">
                    <span class="login100-form-title p-b-20 my-4" style="color:red;font-size:20px !important;">Redirecting ... To Partner Website</span>
                    </center>
                    </div>
                    </body>';
                    echo "<meta http-equiv='refresh' content=0.1;url='$trk2'>";
                }
                else {
                ?>
<br>
<section class="vh-lg-100 mt-5 mt-lg-0 bg-soft d-flex align-items-center">
    <div class="container">
       <div class="row justify-content-center form-bg-image" data-background-lg="./images/signin.svg">
        <div class="col-12 d-flex align-items-center justify-content-center">
        <div class="bg-white shadow shadow border-0 rounded border-grey p-4 p-lg-5 w-100 fmxw-500">
        <div class="text-center text-md-center mb-4 mt-md-0">
        <center><img src="./bg/onx.jpg" height="35px"></img>
                            </div></center>
 
 <form action="" method="post">
     
  <div class="mb-6">
<div class="relative">
<input type="number" name="number" class="block px-2.5 pb-2.5 pt-4 w-full text-sm text-gray-900 bg-transparent rounded-lg border-1 border-gray-500 appearance-none dark:text-white dark:border-white dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" maxlength="10" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" style="font-weight: bold;" placeholder=" " required/>
<label class="absolute text-sm text-gray-600 dark:text-white duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] bg-white dark:bg-gray-600 px-2 peer-focus:px-2 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4 left-1"><i class="fas fa-user"></i> Your Paytm Number</label>
</div>
  
<center>
<button class="button is-fullwidth is-danger rounded-lg" type="submit"><i class="fas fa-check-circle"></i>&nbsp;Submit</button>
</center>
 </form>
 <br>
<div class="notification is-warning" >
Complete Offer And Get ₹<?php echo $camp['user']; ?> Instant PayTM Cashback</div>

    <center>
      <a href="https://telegram.dog/OnCamps" class="button is-info text-white d-inline-flex align-items-center" type="button">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="icon icon-xxs me-2" viewBox="0 0 16 16"> <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.287 5.906c-.778.324-2.334.994-4.666 2.01-.378.15-.577.298-.595.442-.03.243.275.339.69.47l.175.055c.408.133.958.288 1.243.294.26.006.549-.1.868-.32 2.179-1.471 3.304-2.214 3.374-2.23.05-.012.12-.026.166.016.047.041.042.12.037.141-.03.129-1.227 1.241-1.846 1.817-.193.18-.33.307-.358.336a8.154 8.154 0 0 1-.188.186c-.38.366-.664.64.015 1.088.327.216.589.393.85.571.284.194.568.387.936.629.093.06.183.125.27.187.331.236.63.448.997.414.214-.02.435-.22.547-.82.265-1.417.786-4.486.906-5.751a1.426 1.426 0 0 0-.013-.315.337.337 0 0 0-.114-.217.526.526 0 0 0-.31-.093c-.3.005-.763.166-2.984 1.09z"/> </svg>                      &nbsp; &nbsp;Telegram Channel
                                    </a>  
 
</div>
 
 <center>
     
     <div class="d-flex justify-content-center align-items-center mt-4">
        <span class="fw-normal">Wanna Refer n Earn ?
        <a href="refer.php" class="fw-bold" style="color:blue;">Make Link</a>
        </center>
        <br>
        <div class="flex items-center justify-center bg-white rounded-tr-lg rounded-bl-lg h-8 p-0 text-center">
        <img class="h-full mx-2" width="35" height="35" src = "https://onxcamp.xyz/IPay/image/paytm-icon.svg" alt="paytm"/>
        <img class="h-full mx-2" width="20" height="20" src = "https://onxcamp.xyz/IPay/image/google-pay-icon.svg" alt="gpay"/>
        <img class="h-full mx-2" width="20" height="20" src = "https://onxcamp.xyz/IPay/image/phonepe-logo-icon.svg" alt="pe"/>
        <img class="h-full mx-2" width="22" height="22" src = "https://onxcamp.xyz/IPay/image/cash-icon.svg" alt="cash"/>
        <img class="h-full mx-2" width="22" height="22" src = "https://onxcamp.xyz/IPay/image/online-secure-payment-icon.svg" alt="paytm"/>
        </div>
</div>
<br>
</div>
</div>
	<?php
        }
         ?>
<script>
     function telegram(){
  window.location="https://telegram.dog/onxcamps";
 }
</script>


<center>

<footer >
    <span class="text-sm text-gray-500 sm:text-center dark:text-gray-400">© 2022 <a href="https://OnxCamp.xyz/" class="hover:underline">Avenger™</a>. All Rights Reserved.
    </span>
<script src="https://cdn.jsdelivr.net/npm/tw-elements/dist/js/index.min.js"></script>
  </body>
</html>
<!---Product Fromk Avenger--->