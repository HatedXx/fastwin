<?php
require("con.php");
$camp = $_GET['camp'];
$refid = $_GET['ref'];
$sqli = "SELECT * FROM refer where code= '$refid'";
$resultseti = mysqli_query($conn, $sqli);
$recordi = mysqli_fetch_assoc($resultseti);
$num = mysqli_num_rows($resultseti);
$sql = "SELECT * FROM camps WHERE shrtName = '$camp'";
$res = mysqli_query($conn,$sql);
$camp = mysqli_fetch_assoc($res);
$num = mysqli_num_rows($res);
?>
<!DOCTYPE html>
<html lang="en">
     <head>
         <meta name="theme-color" content="#FF7600">
         <meta name="msapplication-navbutton-color" content="#FFB700">
         <meta name="apple-mobile-web-app-status-bar-style" content="#FFB700">
         
         <meta charset="utf-8"> 
         <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> 
          <meta name="description" content="Secure Instant Payment Panel - for Campaign Makers For Better Campaigns.">
          <meta property='og:url' content="https://Onxcamp.xyz/Pay"/>
          <meta property='og:type' content="website"/>
          <link rel="shortcut icon" href="onx.png" type="image/x-icon">
<link href="app.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src='https://www.google.com/recaptcha/api.js' async defer ></script>

<title> Onx ~ CashBack Offers </title> 
</head> 
<body> 

<style>
.animatert
{
   text-transform: uppercase;
  background-image: linear-gradient(
    -225deg,
    #59f093 0%,
    #07f09a 29%,
    #07f0ae 67%,
    #2d5248 100%
  );
  background-size: auto auto;
  background-clip: border-box;
  background-size: 200% auto;
  color: #fff;
  background-clip: text;
  text-fill-color: transparent;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: textclip 2s linear infinite;
  display: inline-block;
      font-size: 13.6px;
       font-weight: bold;
}

@keyframes textclip {
  to {
    background-position: 200% center;
  }
}
div.a {
  text-align: center;
}
body, .form-control, .promo-content { background-color: #f5f2eb; }
.fontrs {
          position: absolute;
          top: -40px;
          right: 10px;
          /*background: red;*/
          color: White;
          padding-top: 18px;
          padding-right: 20px;
          border-radius: 0px 130px 0 450px;
          padding-bottom: 18px;
          padding-left: 25px;
          animation: coloranim 20s infinite;
        }
        h2,h3,h4 {
             position: absolute;
            font-family: 'Montserrat';
        }
        @keyframes coloranim {
  0% {background: red;}
  17% {background: green;}
  34% {background: gold;}
  56% {background: indigo;}
  70% {background: blue;}
  85% {background: orange;}
  100% {background: red;}
}
        .box {
            z-index: 200;
        }
.promo-main-section { padding-bottom: 50px; }
.home-wrapper, .promo-offer-block, .form-control, .promo-content { color: #4f5a80; }
.hp-social-title, .promo-head-title, .frm-disc, .form-control:focus, .frm-label { color: #314483; }
.label-disc { color: #8d9ab1; }
.promo-offer-block, .home-wrapper { background-image: linear-gradient(135deg, #fff, #eef6fa); box-shadow: 0 15px 50px 0 rgb(85, 95, 109, .1); }
.primary-btn { /* border-color: #4c60a2; */ display: inline-block; background-color: #FFC500; color: #000000; border: 1px solid transparent; /* background-image: linear-gradient(135deg, #638fba, #46569e); */ /* box-shadow: 2px 6px 15px rgba(88, 114, 181, .35); */ padding: 8px 20px; transition: .1s ease-in-out; transition-property: color, background-color, background-position, border-color, box-shadow; border-radius: 500px; font-family: Montserrat; font-weight: 900; border: 1px solid black; font-size: 13px; text-transform: uppercase; } 
.btn-left-icon { max-height: 30px; margin-right: 10px; }
.primary-btn:hover { color: #fff; text-decoration: none; }
button:focus { outline: 0; }
.join-telegram-btn { position: fixed; bottom: 0; width: 100%; border-radius: 0; left: 0; right: 0; }
</style> 
<?php
            if ($num == 0){
                echo '<body>
                <center>
                <div class="p-4">
                <span class="login100-form-title p-b-20 my-4" style="color:red;font-size:20px !important;">Campaign Not Exists Over</span>
                </center>
                </div>
                </body>';
                echo "<meta http-equiv='refresh' content=0.1;url='https://telegram.dog/OnxCamps'>";
                return;
            }
            if ($camp['status'] !== "Active"){
                echo '<body>
                <center>
                <div class="p-4">
                <span class="login100-form-title p-b-20 my-4" style="color:red;font-size:20px !important;">Campaign Paused / Off</span>
                </center>
                </div>
                </body>';
                echo "<meta http-equiv='refresh' content=0.1;url='https://telegram.dog/OnxCamps'>";
                return;
            }
                if (isset($_POST['number'])){
                    $paytm = $_POST['number'];
                    $refer = $recordi['number'];
                    $trk1 = $camp['tracking'];
                    $track = $camp['panel'];
                    $track2 = $camp['panel1'];
                    $trk2 = "$trk1&$track=$paytm&$track2=$refer";
                    
                    echo '<body>
                    <center>
                    <div class="p-4">
                    <span class="login100-form-title p-b-20 my-4" style="color:red;font-size:20px !important;">Redirecting ... To Partner Website</span>
                    </center>
                    </div>
                    </body>';
                    echo "<meta http-equiv='refresh' content=0.1;url='$trk2'>";
                }
                else {
                ?>
<section class="promo-main-section"> 
<div class="promo-banner" style="background-image: url('https://onxcamp.xyz/Camp/c/camp.png');">
<div class="container"> 
<div class="pro-banner-head"> 
<br>
<br>
<center><h1 style="color:#fff;"><?php echo $camp['step1']; ?> </h1> </center>
</div> 
</div> 
</div> 
</div>

<div class="container"> <div class="row justify-content-center">
<div class="col-lg-8 col-md-9"> 
<font class="fontrs" color="red">₹<?php echo $camp['user']; ?></font>
<div class="promo-offer-block rounded bg-white mb-4">
    <div class="overlay"></div>
<div class="promo-offer-block rounded bg-white mb-4"> 
<div class="promo-offer-head border-bottom"> <div class='p-3'>
<h2 class="promo-head-title"><?php echo $camp['name']; ?></h2>
<br>
</div> 
</div> 
<div class="promo-offer-content"> 
<div class="promo-frm p-3"> 
<div class="form-group row"> 
<label for="inputEmail3" class="col-lg-5 col-form-label"> 
<span class="d-block frm-label mb-2"><img src='image/approved-profile-icon.svg' width='15' height='15' /> Enter Paytm Number </span> 
<span class="label-disc">cashback will be transfer to your paytm number instant.</span> 
</label> <div class="col-lg-7">
<form action='' method='post'>
<input type='number' minlength='10' id='UserPhoneNum' name='number' class='form-control' maxlength='10' placeholder='Enter Paytm Number' required><br><center>

<div class='text-center pt-3'> <button type='submit' class='primary-btn px-5 w-full' style='width:100%'><img src='image/tick-symbol-icon.svg' width='16' height='16' /> Submit</button> </div>
</form>
 </div>
 </div> 
 <div class="promo-hr"> 
 <div class="promo-hr-icon">
 </div> 
 </div> 
 <h3 class="frm-disc"></h3> <img src = "image/trophy-cup-svgrepo-com.svg" alt="gift" style="float:right" width="70" height="70" style="vertical-align:middle"/><small>100 % Secure</small><img src = "image/safe-icon.svg" alt="safe" style="float:middle" width="20" height="20" />
 </div>
<div class="promo-block-bottom border-bottom p-3"> 
<div class="row mb-4"> 
<div class="col-lg-5"> 
<div class="col-lg-7"> 
</div> 
</div> 
</div> 
</div> 
</div> 
</div>
<div class="text-center"> <a href="https://www.telegram.dog/ONXCAMP" target="_blank"  style="background: #00ACFF" class="join-telegram-btn primary-btn px-3"> <img class="btn-left-icon" src="https://www.lootchamp.in/telegram.png" /> Join Telegram</a> 
</div> 
</div> 
 
<center><img width="26" height="26" src = "image/google-pay-icon.svg" alt="gpay"/>&nbsp;&nbsp;&nbsp;<img width="35" height="35" src = "image/paytm-icon.svg" alt="paytm"/>&nbsp;&nbsp;&nbsp;<img width="22" height="22" src = "image/phonepe-logo-icon.png" alt="pe"/>&nbsp;&nbsp;&nbsp;<img width="22" height="22" src = "image/cash-icon.svg" alt="cash"/>&nbsp;&nbsp;&nbsp;<img width="22" height="22" src = "image/online-secure-payment-icon.svg" alt="badge"/></center>

</section>
<?php
        }
         ?>
<body>
<html>