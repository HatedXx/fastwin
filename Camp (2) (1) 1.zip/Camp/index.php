<?php
require("con.php");
$sql = "SELECT * FROM camps WHERE status = 'Active'";
$query = mysqli_query($conn,$sql);
?>
<script>if(performance.navigation.type == 2){
   location.reload(true);
}</script>
<!doctype html>
<html>
<head>
  <meta name="apple-mobile-web-app-status-bar-style" content="#FFB700">
  <meta name="description" content="Onx in an affiliate marketing portal. here you will get many offers with high payout 100% Indian 100% Trusted">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://unpkg.com/@themesberg/flowbite@1.3.0/dist/flowbite.min.css" />
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>Home</title>
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tw-elements/dist/css/index.min.css" />
<script src="https://cdn.tailwindcss.com"></script>
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="./Assets/loader.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<script src="https://unpkg.com/flowbite@1.5.3/dist/datepicker.js"></script>
<script>
    if (localStorage.getItem('color-theme') === 'dark' || (!('color-theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark')
    }
</script>
<style>
.tittle {
text-transform: uppercase;
background: linear-gradient(to right, #30CFD0 0%, #ff1361 67%, #fff800 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
animation: textclip 2s linear infinite;
font: {size: 20vw;family: $font;};
}
@keyframes textclip {
  to {
    background-position: 200% center;
  }
}
*{
     margin:0;
     font-weight: bold;
     padding:0;
     font-family: 'poppins', sans-serif;
    }
   p{
         font-family: 'poppins', sans-serif;

   }
    @keyframes slideInFromLeft {
  0% {
    transform: translateX(-100%);
  }
  100% {
    transform: translateX(0);
  }
}

.movem {  
  animation: 1s ease-out 0s 1 slideInFromLeft;
}
 .so{
  width:30%;
 }
</style>
</head>
<body class="dark:bg-gray-600" style="font-family: 'poppins', sans-serif;">
        <div id="preloader"></div>
        <nav class="bg-white shadow-md border-gray-200 px-2 sm:px-4 py-2.5 rounded dark:bg-gray-800">
  <div class="container flex flex-wrap justify-between items-center mx-auto">
    <a href="#" class="flex items-center">
        <img src="Https://OnxCamp.xyz/IPay/onx.png" class="mr-3 h-9 sm:h-9 rounded-full" alt="Onx" />
        <span class="self-center text-xl font-semibold whitespace-nowrap dark:text-white">Splash Media Offers</span>
    </a>
    <div class="flex md:order-2">
    <button id="theme-toggle" type="button" class="text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 rounded-lg text-sm p-2.5">
    <svg id="theme-toggle-dark-icon" class="hidden w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z"></path></svg>
    <svg id="theme-toggle-light-icon" class="hidden w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" fill-rule="evenodd" clip-rule="evenodd"></path></svg>
</button>
</nav>
<div class="p-4">
    <div class="text-center fw-bolder container movem">
<h3 class="tittle text-center" style="font-size:25px;">Free Paytm Cash offers</h3>
</div>
<br>
<div class="row">
<?php
    while ($row = mysqli_fetch_assoc($query)){
                ?>
                <div class"flex flex-col items-center pb-10">
    <div class="p-6 max-w-sm bg-white rounded-lg border border-gray-200 shadow-md dark:bg-gray-800 dark:border-gray-700">
        <center><img src="./bg/<?php echo $row['bg']; ?>" style="border-radius: 20%;" width="150"></center>
    <a href="#">
        <h5 style="box-shadow: none; padding: 15px;color: #777; border-radius: 5px; font-size: 28px;"><?php echo $row['name']; ?></h5>
    </a>
    <p class="mb-3 text-gray-500 dark:text-gray-400">
        <ul class="space-y-0 max-w-md list-inside text-gray-500 dark:text-gray-400">
    <li class="flex items-center">
        <svg class="w-4 h-4 mr-1.5 text-green-500 dark:text-green-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>
        <?php echo $row['step1']; ?>
    </li>
    <li class="flex items-center">
        <svg class="w-4 h-4 mr-1.5 text-green-500 dark:text-green-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>
        User : <?php echo $row['user']; ?>₹  ||  Refer : <?php echo $row['refer'];?>₹
    </li>
    <li class="flex items-center">
        <svg class="w-4 h-4 mr-1.5 text-red-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path></svg>
        Dont Use Any Tricks Do Genuienly !
    </li>
</ul>
</p>
<br>
<form method="get" action="camp.php">
    <button class="inline-flex items-center py-2 px-3 text-sm font-medium text-center text-white rounded-lg bg-gradient-to-r from-cyan-500 to-blue-500 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-cyan-300 dark:focus:ring-cyan-800">
        <svg class="ml-2 -mr-1 w-4 h-4" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M5 5a3 3 0 015-2.236A3 3 0 0114.83 6H16a2 2 0 110 4h-5V9a1 1 0 10-2 0v1H4a2 2 0 110-4h1.17C5.06 5.687 5 5.35 5 5zm4 1V5a1 1 0 10-1 1h1zm3 0a1 1 0 10-1-1v1h1z" clip-rule="evenodd"></path><path d="M9 11H3v5a2 2 0 002 2h4v-7zM11 18h4a2 2 0 002-2v-5h-6v7z"></path></svg>&nbsp;&nbsp;Claim
    </button>
    <input type="hidden" name="camp" value= "<?php echo $row['shrtName']?>">
            </form>
</div>
<br>
<?php
            }
            ?>

</div>   

<div class="border border-gray-200 relative overflow-x-auto rounded shadow-md sm:rounded-lg">
<table class="w-full text-sm text-left text-gray-500 dark:text-gray-400" id="myTable">
<thead class="text-xs text-gray-700 uppercase bg-gray-100 dark:bg-gray-700 dark:text-gray-400">
<tr>
<th scope="col" class="px-6 py-3">
Name
</th>
<th scope="col" class="px-6 py-3">
Status
</th>
</tr>
</thead>
<tbody>
             <?php 
           
             $sql = "SELECT * FROM camps";
             $resultset = mysqli_query($conn, $sql);
                while( $record = mysqli_fetch_assoc($resultset) ) {
                    $offerid=$record['offerid'];
                  $stat = '<i class="fa fa-times-circle" style="color:red">Paused</i>';
                 if ($record['status'] == 'Active'){
                 $stat = '<i class="fa fa-check-circle green-color" style="color:green">Active</i>';
                   }
                  ?>
<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
<th scope="row" class="px-6 py-4 font-medium flex items-center text-gray-900 dark:text-white whitespace-nowrap">
<img src="./bg/<?php echo $record['bg']; ?>" style="width:35px; height:35px; border-radius:50%; border:1px solid green; margin-right:7px;"></img><?php echo $record['name']; ?></th>
<td class="px-6 py-4">
<?php echo $stat; ?>
</td>
</tr>

<?php } ?>
</tbody>
</table>
</div>
<br>
<div id="carouselExampleCaptions" class="carousel slide relative" data-bs-ride="carousel">
  <div class="carousel-indicators absolute right-0 bottom-0 left-0 flex justify-center p-0 mb-4">
    <button
      type="button"
      data-bs-target="#carouselExampleCaptions"
      data-bs-slide-to="0"
      class="active"
      aria-current="true"
      aria-label="Slide 1"
    ></button>
    <button
      type="button"
      data-bs-target="#carouselExampleCaptions"
      data-bs-slide-to="1"
      aria-label="Slide 2"
    ></button>
    <button
      type="button"
      data-bs-target="#carouselExampleCaptions"
      data-bs-slide-to="2"
      aria-label="Slide 3"
    ></button>
  </div>
  <div class="carousel-inner relative w-full overflow-hidden">
    <div class="carousel-item active relative float-left w-full">
      <div class="relative overflow-hidden bg-no-repeat bg-cover" style="background-position: 50%;">
        <img src="./bg/image.jpg" class="block w-full" />
        <div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed bg-black opacity-50"></div>
      </div>
      <div class="carousel-caption hidden md:block absolute text-center">
        <h5 class="text-xl">Share</h5>
        <p>Share Our Camps And Earn More.</p>
      </div>
    </div>
    <div class="carousel-item relative float-left w-full">
      <div class="relative overflow-hidden bg-no-repeat bg-cover" style="background-position: 50%;">
        <img src="./bg/image1.jpg" class="block w-full" />
        <div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed bg-black opacity-50"></div>
      </div>
      <div class="carousel-caption hidden md:block absolute text-center">
        <h5 class="text-xl">Earn</h5>
        <p>Earn Together With Us With Existing New Offers You Have Ever Seen.</p>
      </div>
    </div>
    <div class="carousel-item relative float-left w-full">
      <div class="relative overflow-hidden bg-no-repeat bg-cover" style="background-position: 50%;">
        <img src="./bg/image3.jpg" class="block w-full" />
        <div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed bg-black opacity-50"></div>
      </div>
      <div class="carousel-caption hidden md:block absolute text-center">
        <h5 class="text-xl">Forever</h5>
        <p>Lets Make Some Money Peoples !...</p>
      </div>
    </div>
  </div>
  <button
    class="carousel-control-prev absolute top-0 bottom-0 flex items-center justify-center p-0 text-center border-0 hover:outline-none hover:no-underline focus:outline-none focus:no-underline left-0"
    type="button"
    data-bs-target="#carouselExampleCaptions"
    data-bs-slide="prev"
  >
    <span class="carousel-control-prev-icon inline-block bg-no-repeat" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button
    class="carousel-control-next absolute top-0 bottom-0 flex items-center justify-center p-0 text-center border-0 hover:outline-none hover:no-underline focus:outline-none focus:no-underline right-0"
    type="button"
    data-bs-target="#carouselExampleCaptions"
    data-bs-slide="next"
  >
    <span class="carousel-control-next-icon inline-block bg-no-repeat" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<br>
<div class="p-3 border border-gray-500 dark:border-white relative overflow-x-auto rounded-lg shadow-lg sm:rounded-lg">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Refer And Earn</h5>
    </a>
    <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">We Offer Fixed Rewards for every Successfull Referrals.</p>
    <center><a href="refer.php" class="inline-flex items-center py-2 px-3 text-sm font-medium text-center text-white rounded-lg bg-gradient-to-br from-green-600 to-sky-400 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-pink-200 dark:focus:ring-pink-800 font-medium">
        Refer & Earn
        <svg aria-hidden="true" class="ml-2 -mr-1 w-4 h-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
    </a></center>
</div>
<br>
<div class="p-3 border border-gray-500 dark:border-white relative overflow-x-auto rounded-lg shadow-lg sm:rounded-lg">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Check Refer</h5>
    </a>
    <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">Check Your Successful Refers Done !.</p>
    <center><a href="check.php" class="inline-flex items-center py-2 px-3 text-sm font-medium text-center text-white rounded-lg bg-gradient-to-br from-rose-600 to-sky-400 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-pink-200 dark:focus:ring-pink-800 font-medium">
        Check Refer
        <svg aria-hidden="true" class="ml-2 -mr-1 w-4 h-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
    </a></center>
</div>
<br>
 <div class="" style="display:flex;justify-content:center;">
  <div class="p-3 border border-gray-500 dark:border-white relative overflow-x-auto rounded-lg shadow-lg sm:rounded-lg" style="margin:10px;">
<center>
   <div class="card-body">
    <h5 class="card-title" style="font-size:50px;text-align:center;"><i class="fa fa-youtube" style="color:#FF0000;" aria-hidden="true"></i></h5>
    <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">Subscribe On Youtube</p>
    <a onclick="youtube()" class="inline-flex items-center py-2 px-3 text-sm font-medium text-center text-white rounded-lg bg-gradient-to-br from-pink-500 to-orange-400 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-pink-200 dark:focus:ring-pink-800 font-medium">Visit</a>
  </div>
</center>
  </div>
  <div class="p-3 border border-gray-500 dark:border-white relative overflow-x-auto rounded-lg shadow-lg sm:rounded-lg" style="margin:10px;">
<center>
   <div class="card-body">
    <h5 class="card-title" style="font-size:50px;text-align:center;"><i class="fa fa-telegram" style="color:#0088CC;" aria-hidden="true"></i></h5>
    <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">Join Telegram Channel</p>
    <a onclick="telegram()" class="inline-flex items-center py-2 px-3 text-sm font-medium text-center rounded-lg text-white bg-gradient-to-r from-purple-500 to-pink-500 hover:bg-gradient-to-l focus:ring-4 focus:outline-none focus:ring-purple-200 dark:focus:ring-purple-800">Visit</a>
  </div>
</center>
</div>
</div>
<div class="p-3 border border-gray-500 dark:border-white relative overflow-x-auto rounded-lg shadow-lg sm:rounded-lg" style="margin:10px;">
<center>
   <div class="card-body">
    <h5 class="card-title" style="font-size:50px;text-align:center;"><i class="fa fa-user" aria-hidden="true"></i></h5>
    <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">Ask queries on Telegram bot</p>
    <a onclick="tgBot()" class="inline-flex items-center py-2 px-3 text-sm font-medium text-center text-gray-900 bg-gradient-to-r from-red-200 via-red-300 to-yellow-200 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-red-100 dark:focus:ring-red-400 font-medium rounded-lg">Visit</a>
  </div>
</center>
</div>
</div>
<br>
 <section id="contact" class="contact_area relative pt-18 pb-120">
        <div class="contact_image flex items-center justify-end">
            <div class="image lg:pr-13">
                <img src="./bg/contact.svg" alt="about">
            </div>
        </div> 
        <center>
    <h6 style="text-shadow:none !important">
    <svg style="transform:translateY(2px)" xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="none" viewBox="0 0 12 12">
    <path fill="#34A853" d="M6 .5l-4.5 2v3c0 2.775 1.92 5.37 4.5 6 2.58-.63 4.5-3.225 4.5-6v-3L6 .5zm-1 8l-2-2 .705-.705L5 7.085 8.295 3.79 9 4.5l-4 4z"/>
    </svg>
    <span style="color:#606962;font-size:10px">100% Safer & Secure</h6></center>
                         
<center>
        <footer class="p-4 bg-white sm:p-6 dark:bg-gray-900">
    <div class="md:flex md:justify-between">
        <div class="mb-6 md:mb-0">
            <a href="https://OnxCamp.xyz/" class="flex items-center">
                <img src="Https://Onxcamp.xyz/IPay/onx.png" class="mr-3 h-8" alt="FlowBite Logo" />
                <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">OnxCamp</span>
            </a>
        </div>
        <div class="grid grid-cols-2 gap-8 sm:gap-6 sm:grid-cols-3">
            <div>
                <h2 class="mb-6 text-sm font-semibold text-gray-900 uppercase dark:text-white">Resources</h2>
                <ul class="text-gray-600 dark:text-gray-400">
                    <li class="mb-4">
                        <a href="https://OnxCamp.xyz/" class="hover:underline">OnxCamp</a>
                    </li>
                    <li>
                        <a href="https://telegram.dog/onxcamps/" class="hover:underline">Telegram</a>
                    </li>
                </ul>
            </div>
            <div>
                <h2 class="mb-6 text-sm font-semibold text-gray-900 uppercase dark:text-white">Legal</h2>
                <ul class="text-gray-600 dark:text-gray-400">
                    <li class="mb-4">
                        <a href="#" class="hover:underline">Privacy Policy</a>
                    </li>
                    <li>
                        <a href="#" class="hover:underline">Terms &amp; Conditions</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <hr class="my-6 border-gray-200 sm:mx-auto dark:border-gray-700 lg:my-8" />
    <div class="sm:flex sm:items-center sm:justify-between">
        <span class="text-sm text-gray-500 sm:text-center dark:text-gray-400">© 2022 <a href="https://OnxCamp.xyz/" class="hover:underline">Avenger™</a>. All Rights Reserved.
        </span>
        <div class="flex mt-4 space-x-6 sm:justify-center sm:mt-0">
            <a href="#" class="text-gray-500 hover:text-gray-900 dark:hover:text-white">
                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" aria-hidden="true"><path fill="#3b5998" fill-rule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clip-rule="evenodd" /></svg>
                <span class="sr-only">Facebook page</span>
            </a>
            <a href="#" class="text-gray-500 hover:text-gray-900 dark:hover:text-white">
                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" aria-hidden="true"><path fill="#8a3ab9" fill-rule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z" clip-rule="evenodd" /></svg>
                <span class="sr-only">Instagram page</span>
            </a>
            <a href="#" class="text-gray-500 hover:text-gray-900 dark:hover:text-white">
                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" aria-hidden="true"><path fill="#1DA1F2" d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" /></svg>
                <span class="sr-only">Twitter page</span>
            </a>
            <img width="35" height="35" src = "https://onxcamp.xyz/IPay/image/paytm-icon.svg" alt="paytm"/>
    <img width="20" height="20" src = "https://onxcamp.xyz/IPay/image/google-pay-icon.svg" alt="gpay"/>
    <img width="20" height="20" src = "https://onxcamp.xyz/IPay/image/phonepe-logo-icon.png" alt="pe"/>
    <img width="22" height="22" src = "https://onxcamp.xyz/IPay/image/cash-icon.svg" alt="cash"/>
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/tw-elements/dist/js/index.min.js"></script>
<script src="./Assets/dark.js"></script>
<script src="./Assets/animate.js"></script>
<script>
 function telegram(){
  window.location="https://telegram.dog/OnxCamps";
 }
 function youtube(){
  window.location="https://youtube.com/channel/";
 }
 function tgBot(){
window.location="https://telegram.dog/Stark_AiBot";
 }
</script>
</body>
</html>
<!--A product From Avenger-->