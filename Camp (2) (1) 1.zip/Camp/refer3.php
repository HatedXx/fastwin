<!DOCTYPE html>
<html lang="en"> 
<head> 
<meta name="theme-color" content="#ff0051">
<meta name="msapplication-navbutton-color" content="#ff0051">
<meta name="apple-mobile-web-app-status-bar-style" content="#ff0051">
<meta charset="utf-8"> 
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> 
<meta name="description" content="Shop online at our partner and earn real cashback that is awarded instantly."> 
<link rel="shortcut icon" href="onx.png" type="image/x-icon">
<link href="./app.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<title>Refer & Earn - Onx</title> 
</head> 
<body> 
<style> 
body, .form-control, .promo-content { background-color: #f5f2eb; }
.promo-main-section { padding-bottom: 50px; }
.home-wrapper, .promo-offer-block, .form-control, .promo-content { color: #4f5a80; }
.hp-social-title, .promo-head-title, .frm-disc, .form-control:focus, .frm-label { color: #314483; }
.label-disc { color: #8d9ab1; }
.promo-offer-block, .home-wrapper { background-image: linear-gradient(135deg, #fff, #eef6fa); box-shadow: 0 15px 50px 0 rgb(85, 95, 109, .1); }
.primary-btn { /* border-color: #4c60a2; */ display: inline-block; background-color: #ff634d; color: #fff; border: 1px solid transparent; /* background-image: linear-gradient(135deg, #638fba, #46569e); */ /* box-shadow: 2px 6px 15px rgba(88, 114, 181, .35); */
padding: 8px 20px; transition: .1s ease-in-out; transition-property: color, background-color, background-position, border-color, box-shadow; border-radius: 500px; font-family: Montserrat; font-weight: 400; font-size: 13px; text-transform: uppercase; }
.btn-left-icon { max-height: 30px; margin-right: 10px; }
.primary-btn:hover { color: #fff; text-decoration: none; }
button:focus { outline: 0; }
.join-telegram-btn { position: fixed; bottom: 0; width: 100%; border-radius: 0; left: 0; right: 0; }
</style> 
<section class="promo-main-section"> 
<div class="promo-banner" style="background-image: url('./bh.jpg');"> 
<div class="promo-banner-content text-white position-relative text-center"> 
<div class="container"> 
<div class="pro-banner-head"> 
<h1>Refer and Earn </h1> 
</div> 
</div> 
</div> 
</div>
<?php
     require("con.php");
     $sql = "SELECT * FROM camps";
     $query = mysqli_query($conn,$sql);
     ?>
<div class="container"> 
<div class="row justify-content-center">
<div class="col-lg-8 col-md-9"> 
<div class="promo-offer-block rounded bg-white mb-4"> 
<div class="promo-offer-content"> 
<div class="promo-frm p-3">
 <?php
if(isset($_POST['submit'])){
    $paytm=$_POST['paytm'];
    $offer=$_POST['offer'];
    function generateRandomString($length) {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';
            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }
            return $randomString;
        }
        $refer_id = generateRandomString(6);

$sqlio = "Select * from refer where number='$paytm'"; 
$resulto = mysqli_query($conn, $sqlio); 
  $numi = mysqli_num_rows($resulto); 

if($numi == 0) {
$sql="INSERT INTO `refer` (`number`,`code`) VALUES ('$paytm','$refer_id')";

$res=mysqli_query($conn,$sql);
if($res){


}
}
$s="Select * from refer where number='$paytm'";
$rs=mysqli_query($conn,$s);
$rd = mysqli_fetch_assoc($rs);
$id=$rd['code'];


$link=$_SERVER['SERVER_NAME']."/Task/camp.php?&camp=$offer&ref=$id";
echo "
<script>prompt('You Refer Link Generated Sucessfully','$link');window.location.href='refer.php';</script>

";
}else{
    ?>
<form action="" method="post">
    <div class='form-group row'> 
    <label for='offer_id' class='col-lg-5 col-form-label'>
    <span class='d-block frm-label mb-2'> Select Offer </span> 
    <span class='label-disc'>Select Offer</span> </label> 
    <div class='col-lg-7'>
    <select class="form-control" name="offer">
  <option selected value="0">Select Campaign</option>
  <?php 
    while ($row = mysqli_fetch_assoc($query)){
echo '<option value="'.$row['shrtName'].'">'.$row['name'].'</option>';
}
?></option>
<?php } ?>
</select>
</div> </div>
<div class='form-group row'> 
<label for='UserPhoneNum' class='col-lg-5 col-form-label'> 
<span class='d-block frm-label mb-2'> Your Phone Number </span> 
<span class='label-disc'>Your Phone Number</span> </label> 
<div class='col-lg-7'> 
<input required type='text' minlength='10' maxlength='10' required id='UserPhoneNum' name='paytm' class='form-control' placeholder='Your Phone Number'> 
</div> 
</div>
<div class='text-center p-3'>							
<button type='submit' class='primary-btn px-5' name='submit' >Submit</button> 
</div>					 
</form>

</div>
</div> 
</div> 
</div> 
</div> 
</div>
<center>
    <img width="26" height="26" src = "./image/google-pay-icon.svg" alt="gpay"/>&nbsp;&nbsp;&nbsp;
    <img width="35" height="35" src = "./image/paytm-icon.svg" alt="paytm"/>&nbsp;&nbsp;&nbsp;
    <img width="22" height="22" src = "./image/phonepe-logo-icon.png" alt="pe"/>&nbsp;&nbsp;&nbsp;
    <img width="22" height="22" src = "./image/cash-icon.svg" alt="cash"/>&nbsp;&nbsp;&nbsp;
    <img width="22" height="22" src = "./image/online-secure-payment-icon.svg" alt="badge"/>
    </center>
    </section>
<style>
/* Chrome, Safari, Edge, Opera */input::-webkit-outer-spin-button,input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0;}
/* Firefox */input[type=number] { -moz-appearance: textfield;}
</style>

		 <body>
		     <html>
		         <!---Product Fromk Avenger--->