<?php
// Connecting to the Database
$servername = "localhost";
$username = "armycamp_Loot";
$password = "9693590495@";
$database = "armycamp_Loot";

// Create a connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Die if connection was not successful
if (!$conn){
    die("Sorry we failed to connect: ". mysqli_connect_error());
}
else{
    $connection_done = true; // By @immortal182
}
?>