<?php 
include('con.php');
?>
<!doctype html>
<html>
<head>
  <meta name="apple-mobile-web-app-status-bar-style" content="#FFB700">
  <meta name="description" content="Onx in an affiliate marketing portal. here you will get many offers with high payout 100% Indian 100% Trusted">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://unpkg.com/@themesberg/flowbite@1.3.0/dist/flowbite.min.css" />
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<title>Login</title>
<script src='https://www.google.com/recaptcha/api.js' async defer ></script>
   <script src="https://cdn.tailwindcss.com"></script>
   <link rel="stylesheet" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
   <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<script src="https://unpkg.com/flowbite@1.5.3/dist/datepicker.js"></script>
<script>
    if (localStorage.getItem('color-theme') === 'dark' || (!('color-theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark')
    }
</script>
</head>
<body class="dark:bg-gray-600" style="font-family: 'Montserrat', sans-serif;">
<nav class="bg-white shadow-md border-gray-200 px-2 sm:px-4 py-2.5 rounded dark:bg-gray-800">
  <div class="container flex flex-wrap justify-between items-center mx-auto">
    <a href="#" class="flex items-center">
        <img src="https://onxcamp.xyz/IPay/onx.png" class="mr-3 h-9 sm:h-9 rounded-full" alt="Loots" />
        <span class="self-center text-xl font-semibold whitespace-nowrap dark:text-white">Onx Camp Panel</span>
    </a>
    <div class="flex md:order-2">
    <button id="theme-toggle" type="button" class="text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 rounded-lg text-sm p-2.5">
    <svg id="theme-toggle-dark-icon" class="hidden w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z"></path></svg>
    <svg id="theme-toggle-light-icon" class="hidden w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" fill-rule="evenodd" clip-rule="evenodd"></path></svg>
</button>
    </div>
    
  </div>
</nav>
<div class="p-2">
<br>
<center>
<div class="p-3 border border-gray-500 dark:border-white relative overflow-x-auto rounded-lg shadow-lg sm:rounded-lg">
  <form class="mt-4" method="post" action="" autocomplete="on">
    <div class="form-group mb-6">
    <div class="relative">
      <input type="email" required class="block px-2.5 pb-2.5 pt-4 w-full text-sm text-gray-900 bg-transparent rounded-lg border-1 border-gray-500 appearance-none dark:text-white dark:border-white dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" style="font-weight: bold;" id="exampleInput125" placeholder="Email address" name="email">
      <label for="email" class="absolute text-sm text-gray-600 dark:text-white duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] bg-white dark:bg-gray-600 px-2 peer-focus:px-2 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4 left-1"><i class="fas fa-user"></i> Enter Email ID </label>
</div>
</div>
<div class="form-group mb-6">
        <div class="relative mb-4">
      <input type="password" required class="block px-2.5 pb-2.5 pt-4 w-full text-sm text-gray-900 bg-transparent rounded-lg border-1 border-gray-500 appearance-none dark:text-white dark:border-white dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" style="font-weight: bold;" id="exampleInput126" placeholder="Password" name="password">
      <label for="password" class="absolute text-sm text-gray-600 dark:text-white duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] bg-white dark:bg-gray-600 px-2 peer-focus:px-2 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4 left-1"><i class="fas fa-key"></i> Enter Password</label>
</div>
</div>   
<div class="g-recaptcha" data-sitekey="6LdMlkUiAAAAAAE5tV_lkFsatZi_9rdY9pmpbJoo"></div>
<br>
 <div class="flex justify-between items-center mb-6">
     <a
              href="Forgot.php"
              class="text-blue-600 hover:text-blue-700 focus:text-blue-700 active:text-blue-800 duration-200 transition ease-in-out"
              >Forgot password?</a
            >
          </div>     
    <button type="submit" class="w-full px-6 py-2.5 rounded-lg text-white bg-gradient-to-br from-rose-600 to-indigo-400 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800" name="btnlogin">Login</button>
      
  </form>
  </center>
</div>
    </div>
  </div>
</section>
<script>
   function onSubmit(token) {
     document.getElementById("demo-form").submit();
   }
   var fields = document.querySelectorAll('input[type="password"]');
  for (var i = 0; i < fields.length; i++) {
    fields[i].autocomplete="on";
  }
 </script>
<?php


if (isset($_POST['btnlogin'])) {

  if(!empty($_POST['g-recaptcha-response']))
  {
    $secret = '6LdMlkUiAAAAAKkHl_t5YDgG5n1Szaeo1uEW4xgY';
        $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
        $responseData = json_decode($verifyResponse);
        if($responseData->success){
 session_start();
 
  $em = trim($_POST['email']);
  $pass = trim($_POST['password']);

  $email=mysqli_real_escape_string($conn, $em); 
  $upass = mysqli_real_escape_string($conn, $pass); 

if ($upass == ''){
     ?>    <script type="text/javascript">
                alert("Password is missing!");
                window.location = "login.php";
                </script>
        <?php
}else{
           
        $sql = "SELECT * FROM  `member` WHERE  `email` =  '" . $email . "' AND  `password` =  '" . $upass . "'";
        $result = mysqli_query($conn, $sql);
 
        if ($result){
        $numrows = mysqli_num_rows($result);
    
            if ($numrows == 1) {
                $found_user  = mysqli_fetch_array($result);
                require('session.php');
                $_SESSION['email']  = $found_user['email'];
             ?> 
             <script type="text/javascript">
                  alert('login Sucess Redirecting..');
                      window.location = "admin.php";
                  </script>
             <?php        
          
        
            } else {
                
              ?>    <script type="text/javascript">
                alert("Your Account is Not Approved by Admin");
                window.location = "login.php";
                </script>
        <?php
 
            }
 
         } else {

         die(" Query failed: " );
        }
        
    }      
    
        }else{
echo ' <script type="text/javascript">
                alert("Login Credinals Wrong")
                window.location = "login.php";
                </script>';
}
}else{
  echo ' <script type="text/javascript">
                alert("Captcha Verification Failed ")
                window.location = "login.php";
                </script>';
}
}

?>
</body>
</html>
<!----Product From Avenger--->